// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "Room.h"
#include "Obstacle.h"
#include "TDShootingGameModeBase.h"
#include "PlayableCharacter.h"

// Sets default values
ARoom::ARoom()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootBase"));
	}	
	
	StartLevelTrigger = CreateDefaultSubobject<UBoxComponent>(TEXT("StartLevelTrigger"));
	StartLevelTrigger->SetupAttachment(RootComponent);
		
	StartLevelTrigger->OnComponentBeginOverlap.AddDynamic(this, &ARoom::OnHitTrigger);
}

// Called when the game starts or when spawned
void ARoom::BeginPlay()
{
	Super::BeginPlay();	
}

// Called every frame
void ARoom::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void ARoom::StartLevel_Implementation()
{
	//���Ӹ�� �޾ƿ�
	ATDShootingGameModeBase* MyGameMode = (ATDShootingGameModeBase*)GetWorld()->GetAuthGameMode();
	//��������
	MyGameMode->StartLevel();
}


void ARoom::OnHitTrigger_Implementation(UPrimitiveComponent * OverlappedComponent, AActor * OtherActor, UPrimitiveComponent * OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult)
{	
	APlayableCharacter* Player = Cast<APlayableCharacter>(OtherActor);
	if (Player)
	{			
		//Ʈ���� ����
		StartLevelTrigger->DestroyComponent();

		this->Close();

		//1���� ����
		GetWorldTimerManager().SetTimer(StartLevelTimerHandle, this, &ARoom::StartLevel, 1.f, false);			
	}
}


