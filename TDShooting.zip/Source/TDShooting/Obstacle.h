// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Damageable.h"
#include "Obstacle.generated.h"

UCLASS()
class TDSHOOTING_API AObstacle : public AActor, public IDamageable
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AObstacle();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
private:

	UPROPERTY(EditAnywhere, Category = "Mesh")
		UStaticMeshComponent* Mesh;

	UPROPERTY(EditAnywhere, Category = "Mesh")
		UBoxComponent* Collision;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Durability", meta = (AllowPrivateAccess = "true"))
		int MaxDurability = 5;

	UPROPERTY(VisibleAnywhere, Category = "Durability")
		int CurrentDurability;

	//�ѹ��� �޴� ������
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Durability", meta = (AllowPrivateAccess = "true"))
		int DamagePerHit = 1;

	
public:
	//Damageable �������̽����� ��� ���� �Լ�
	UFUNCTION(BlueprintNativeEvent, Category = "Interaction")
		void Damaged(float Amount);
	virtual void Damaged_Implementation(float Amount) override;
		

	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void CalculateDurability();
	virtual void CalculateDurability_Implementation();


	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void Break();
	virtual void Break_Implementation();

private:

	virtual void CalculateBreak();



};
