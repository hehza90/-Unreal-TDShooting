// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "TDPlayerController.h"



ATDPlayerController::ATDPlayerController()
{
	bShowMouseCursor = true;
	DefaultMouseCursor = EMouseCursor::Crosshairs;
}
