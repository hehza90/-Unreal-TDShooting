// Fill out your copyright notice in the Description page of Project Settings.

#include "TDPlayerController.h"
#include "TDShooting.h"




ATDPlayerController::ATDPlayerController()
{
	bShowMouseCursor = true;
	DefaultMouseCursor = EMouseCursor::Crosshairs;
}

int ATDPlayerController::GetPlayerLife() const
{
	return PlayerLife;
}

int ATDPlayerController::GetScore() const
{
	return Score;
}

void ATDPlayerController::RedusePlayerLife()
{
	PlayerLife--;
}

void ATDPlayerController::AddScore_Implementation(int _Score)
{
	Score = Score + _Score;
}
