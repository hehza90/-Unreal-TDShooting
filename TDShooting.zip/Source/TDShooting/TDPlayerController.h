// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "TDPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class TDSHOOTING_API ATDPlayerController : public APlayerController
{
	GENERATED_BODY()
	
	

public:
	ATDPlayerController();


private:
	int PlayerLife = 3;
	
	int Score = 0;

public:
	//Get,Set
	UFUNCTION(BlueprintCallable)
		int GetPlayerLife() const;

	UFUNCTION(BlueprintCallable)
		int GetScore() const;

	void RedusePlayerLife();
	
	UFUNCTION(BlueprintNativeEvent)
		void AddScore(int _Score);	
	virtual void AddScore_Implementation(int _Score);

};
