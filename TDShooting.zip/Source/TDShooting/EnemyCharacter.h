// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BaseCharacter.h"
#include "EnemyCharacter.generated.h"



/**
 * 
 */
UCLASS()
class TDSHOOTING_API AEnemyCharacter : public ABaseCharacter
{
	GENERATED_BODY()

public:
	AEnemyCharacter();

protected:
	virtual void BeginPlay() override;
	
private:	

	class ATDShootingGameModeBase* MyGameMode;
	
	class APlayableCharacter* Player;



	//���� Ÿ�̸�
	FTimerHandle CanAttackTimerHandle;

	bool CanAttack = true;
	
	UPROPERTY(EditAnywhere, Category = "Attack", meta = (AllowPrivateAccess = "true"))
		int ScorePoint = 10.0f;	

	//�ɷ�ġ
	UPROPERTY(EditAnywhere, Category = "Attack", meta = (AllowPrivateAccess = "true"))
		float EnemyDamage = 20.0f;

	//���� �ֱ�
	UPROPERTY(EditAnywhere, Category = "Attack", meta = (AllowPrivateAccess = "true"))
		float AttackRate = 1.5f;

	//������ Projectile
	UPROPERTY(EditAnywhere, Category = "Attack")
		TSubclassOf<class AProjectile> ProjectileOfEnemy;
	
	//BehaviorTree
	UPROPERTY(EditAnywhere, Category = "Behavior")
		class UBehaviorTree* BotBehavior;


public:
	//Get, Set
	int GetEnemyScore() const;

	UBehaviorTree* GetEnemyBehavior() const;

	void SetPlayerCharacter(APlayableCharacter* Target);


private:
	//���� �ɷ�ġ ����
	void SetEnemyStat();

	//�����ֱ�
	void ToggleCanAttack();

	//����
	void DestroyDeadbody();
	

protected:
	//BaseCharacter���� ���(BlueprintNativeEvent)	
	virtual void Attack_Implementation() override;
	
	
	virtual void Death_Implementation() override;

	//��������
	virtual void DeactiveInvisible() override;
};
