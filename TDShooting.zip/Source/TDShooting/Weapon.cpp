// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "CombatInteraction.h"
#include "PlayableCharacter.h"
#include "Weapon.h"




AWeapon::AWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("WeaponBase"));

	}	
	EquipedMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponMesh"));
	EquipedMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	
	FirePoint = CreateDefaultSubobject<UArrowComponent>(TEXT("FirePoint"));
	FirePoint->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	SetCurrentState(EWeaponState::WS_Idle);
	
}



void AWeapon::BeginPlay()
{
	Super::BeginPlay();
	SetAmmoFull();
}


void AWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	Fire();
	CountDownCooldown(DeltaTime);

	if (CurrentAmmo <= 0)
	{
		StartReload();
	}

	if(IsReloading)
	{
		Reloading(DeltaTime);
	}

}



void AWeapon::SetCurrentState(EWeaponState State)
{
	CurrentState = State;
}





void AWeapon::StartFire()
{
	SetCurrentState(EWeaponState::WS_Shooting);
}


void AWeapon::StopFire()
{
	SetCurrentState(EWeaponState::WS_Idle);
}


void AWeapon::Fire_Implementation()
{
	if (CurrentState != EWeaponState::WS_Shooting)
	{
		return;
	}

	if (IsReloading)
	{
		return;
	}
		
	
	if (IsCooldown)
	{
		return;
	}
	
	//������Ÿ�� �߻縦 �õ��մϴ�.
	if (InteractionOfWeapon)
	{
		if (FirePoint)
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FVector SpawnLocation = FirePoint->GetComponentLocation();
				FRotator SpawnRotation = FirePoint->GetComponentRotation();

				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;

				// �ѱ� ��ġ�� �߻�ü�� ������ŵ�ϴ�.
				ACombatInteraction* Interaction = World->SpawnActor<ACombatInteraction>(InteractionOfWeapon, SpawnLocation, SpawnRotation, SpawnParams);
				CurrentAmmo -= NeedAmmo;
				ResetCooldown();	

			}
		}
	}
}


void AWeapon::CountDownCooldown(float Time)
{
	if (RemainCooldownTime > 0)
	{
		RemainCooldownTime -= Time;		
	}
	else 
	{
		FinishCooldown();
	}
	
}


void AWeapon::FinishCooldown()
{
	IsCooldown = false;
}


void AWeapon::ResetCooldown()
{
	IsCooldown = true;
	RemainCooldownTime = Cooldown;
}



void AWeapon::StartReload()
{
	//źâ�� �ִ�ġ �϶� return
	if (CurrentAmmo == MaxAmmo)
	{
		return;
	}

	if (IsReloading)
	{
		return;
	}
	IsReloading = true;	
	
}



void AWeapon::StopReload()
{
	GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Blue, TEXT("Stop Reload")); // ȭ�����	
	GetWorldTimerManager().ClearTimer(ReloadingTimerHandle);	
	IsReloading = false;
	ReloadProgress = 0;
}


void AWeapon::CompleteReload()
{
	SetAmmoFull();
	IsReloading = false;
	ReloadProgress = 0;
}


void AWeapon::SetAmmoFull()
{
	CurrentAmmo = MaxAmmo;
}


void AWeapon::Reloading(float Time)
{	
	if (ReloadProgress >= ReloadTime) 
	{
		CompleteReload();
	}
	ReloadProgress += Time;
}

