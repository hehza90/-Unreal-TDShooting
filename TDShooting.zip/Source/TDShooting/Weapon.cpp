// Fill out your copyright notice in the Description page of Project Settings.

#include "Weapon.h"
#include "TDShooting.h"
#include "Components/ArrowComponent.h"
#include "Projectile.h"
#include "PlayableCharacter.h"





AWeapon::AWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("WeaponBase"));

	}	
	EquipedMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponMesh"));
	EquipedMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	
	FirePoint = CreateDefaultSubobject<UArrowComponent>(TEXT("FirePoint"));
	FirePoint->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	SetCurrentState(EWeaponState::WS_Idle);
	
}



void AWeapon::BeginPlay()
{
	Super::BeginPlay();
	SetAmmoFull();
}


void AWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	Fire();
	CountDownCooldown(DeltaTime);
	

	if(IsReloading)
	{
		Reloading(DeltaTime);
	}

}





void AWeapon::SetOwnerPlayer(APlayableCharacter * Target)
{
	OwnerPlayer = Target;
}


void AWeapon::SetCurrentState(EWeaponState State)
{
	CurrentState = State;
}


int AWeapon::GetCurrentAmmo() const
{
	return CurrentAmmo;
}


int AWeapon::GetMaxAmmo() const
{
	return MaxAmmo;
}




void AWeapon::HideThisWeapon()
{
	EquipedMesh->SetHiddenInGame(true, true);
}


void AWeapon::RevealThisWeapon()
{
	EquipedMesh->SetHiddenInGame(false, true);
}




void AWeapon::StartFire()
{
	SetCurrentState(EWeaponState::WS_Shooting);
}


void AWeapon::StopFire()
{
	SetCurrentState(EWeaponState::WS_Idle);
}


void AWeapon::Fire_Implementation()
{
	if (CurrentState != EWeaponState::WS_Shooting)
	{
		return;
	}

	if (IsReloading)
	{
		return;
	}
		
	
	if (IsCooldown)
	{
		return;
	}
	
	//������Ÿ�� �߻縦 �õ��մϴ�.
	if (WeaponProjectile)
	{
		if (FirePoint)
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FVector SpawnLocation = FirePoint->GetComponentLocation();
				FRotator SpawnRotation = FirePoint->GetComponentRotation();

				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;

				// �ѱ� ��ġ�� �߻�ü�� ������ŵ�ϴ�.
				AProjectile* SpawnedProjectile = World->SpawnActor<AProjectile>(WeaponProjectile, SpawnLocation, SpawnRotation, SpawnParams);
				SpawnedProjectile->SetDamage(Damage);
				SpawnedProjectile->Activate();
				CurrentAmmo -= NeedAmmo;
				ResetCooldown();	

			}
		}
	}
}





void AWeapon::CountDownCooldown(float Time)
{
	if (RemainCooldownTime > 0)
	{
		RemainCooldownTime -= Time;		
	}
	else 
	{
		FinishCooldown();
	}
	
}


void AWeapon::FinishCooldown()
{
	IsCooldown = false;
}


void AWeapon::ResetCooldown()
{ 
	//��ٿ� ����
	IsCooldown = true;
	RemainCooldownTime = Cooldown;
}





void AWeapon::StartReload()
{
	//źâ�� �ִ�ġ �϶� return
	if (CurrentAmmo == MaxAmmo)
	{
		return;
	}
	//�������϶� return
	if (IsReloading)
	{
		return;
	}
	ReloadProgress = 0;
	IsReloading = true;	
	
}


void AWeapon::StopReload()
{	
	ReloadProgress = 0;	
	IsReloading = false;
	
}


void AWeapon::Reloading(float Time)
{	
	if (ReloadProgress >= ReloadTime) 
	{
		CompleteReload();
	}
	ReloadProgress += Time;
}


void AWeapon::CompleteReload()
{
	SetAmmoFull();
	IsReloading = false;
	ReloadProgress = 0;
}


void AWeapon::SetAmmoFull()
{
	CurrentAmmo = MaxAmmo;
}