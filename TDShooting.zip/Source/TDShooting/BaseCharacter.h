// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Damageable.h"
#include "BaseCharacter.generated.h"

UCLASS()
class TDSHOOTING_API ABaseCharacter : public ACharacter, public IDamageable
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ABaseCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
		

protected:

	//���� Ÿ�̸�,����
	FTimerHandle InvisibleTimer;

	UPROPERTY(EditDefaultsOnly)
		float InvisibleDeactiveTime = 2.f;

	UPROPERTY(EditDefaultsOnly)
		class UParticleSystemComponent* InvisibleParticle;


	UPROPERTY(EditDefaultsOnly, Category = "Character")
		class UArrowComponent* CharacterDirection;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
		class UCapsuleComponent* CharacterCapsule;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
		class UMeshComponent* CharacterMesh;

	//������ ������ ��ġ, ����
	UPROPERTY(EditDefaultsOnly, Category = "Character")
		class UArrowComponent* AttackPoint;



	//Health
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float MaxHealth = 100.0f;

	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		float CurrentHealth = 0;
	
	//Bool Dead
	UPROPERTY(BlueprintReadOnly, VisibleAnywhere, Category = "Character", meta = (AllowPrivateAccess = "true"))
		bool IsDead = false;


protected:
	virtual void SetInitialStat();
	
	//Health ���
	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void CalculateHealth(float Amount);
	virtual void CalculateHealth_Implementation(float Amount);

private:
	//���� ���
	virtual void CalculateDead();

public:

	UFUNCTION(BlueprintNativeEvent, Category = "Action")
		void Attack();
	virtual void Attack_Implementation();
	

	//Damageable �������̽����� ��� ���� �Լ�
	UFUNCTION(BlueprintNativeEvent, Category = "Interaction")
		void Damaged(float Amount);
	virtual void Damaged_Implementation(float Amount) override;

	UFUNCTION(BlueprintNativeEvent, Category = "Character")
		void Death();
	virtual void Death_Implementation();


	//������ ���� ����
	virtual void DeactiveInvisible();
};

