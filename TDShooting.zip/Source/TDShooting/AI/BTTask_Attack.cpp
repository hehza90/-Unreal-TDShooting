// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackBoardComponent.h"
#include "BehaviorTree/BlackBoard/BlackboardKeyAllTypes.h"
#include "EnemyAIController.h"
#include "PlayableCharacter.h"
#include "EnemyCharacter.h"
#include "BTTask_Attack.h"





EBTNodeResult::Type UBTTask_Attack::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AEnemyAIController* EnemyAC = Cast<AEnemyAIController>(OwnerComp.GetAIOwner());
	AEnemyCharacter* Enemy = Cast <AEnemyCharacter>(EnemyAC->GetPawn());
	APlayableCharacter* Target = Cast<APlayableCharacter>(OwnerComp.GetBlackboardComponent()->GetValueAsObject("Target"));
	
	
	if (Target)
	{	
		Enemy->Attack();		
		return EBTNodeResult::Succeeded;
	}
	else
	{
		return EBTNodeResult::Failed;
	}
	return EBTNodeResult::Failed;
}