// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "BehaviorTree/BTService.h"
#include "BT_Service_CheckForPlayer.generated.h"

/**
 * 
 */
UCLASS()
class TDSHOOTING_API UBT_Service_CheckForPlayer : public UBTService
{
	GENERATED_BODY()
	
	
public:
	UBT_Service_CheckForPlayer();

	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	
};
