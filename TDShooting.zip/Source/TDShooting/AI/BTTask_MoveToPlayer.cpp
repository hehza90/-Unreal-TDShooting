// Fill out your copyright notice in the Description page of Project Settings.

#include "BTTask_MoveToPlayer.h"
#include "TDShooting.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackBoardComponent.h"
#include "BehaviorTree/BlackBoard/BlackboardKeyAllTypes.h"
#include "EnemyAIController.h"
#include "PlayableCharacter.h"
#include "EnemyCharacter.h"






EBTNodeResult::Type UBTTask_MoveToPlayer::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AEnemyAIController* EnemyAC = Cast<AEnemyAIController>(OwnerComp.GetAIOwner());
	
	APlayableCharacter* Target = Cast<APlayableCharacter>(OwnerComp.GetBlackboardComponent()->GetValueAsObject("Target"));

	if (Target)
	{
		EnemyAC->MoveToActor(Target, EnemyAC->AttackStartRange-100.0f, true, true, true, 0, true);
		return EBTNodeResult::Succeeded;	
	}
	else
	{
		return EBTNodeResult::Failed;
	}
	return EBTNodeResult::Failed;
}