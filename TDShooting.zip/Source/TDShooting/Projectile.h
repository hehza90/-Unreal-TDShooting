// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatInteraction.h"
#include "GameFramework/Actor.h"
#include "Projectile.generated.h"

/**
 * 
 */
UCLASS()
class TDSHOOTING_API AProjectile : public ACombatInteraction
{
	GENERATED_BODY()
	
public:
	AProjectile();

	UPROPERTY(EditAnywhere)
		class USphereComponent* ProjectileCollision;

	UPROPERTY(EditAnywhere)
		class UStaticMeshComponent* ProjectileMesh;
	
	UPROPERTY(EditAnywhere)
		class UParticleSystemComponent* ParticleSystem;

	UPROPERTY(EditAnywhere)
		class UProjectileMovementComponent* ProjectileMovement;
	
	//Ȱ��ȭ ���� (�ڵ���� ������)
	bool IsActivate = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Damage")
		float Damage=0;


//Get, Set
	//������ ����
	UFUNCTION(BlueprintCallable, Category = "Damage")
		void SetDamage(float _Damage);
	
	//Ȱ��ȭ
	void Activate();

	UFUNCTION(BlueprintNativeEvent, Category = "Collision")
		void OnHit(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,	const FHitResult &SweepResult);
	void OnHit_Implementation(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult);



};
