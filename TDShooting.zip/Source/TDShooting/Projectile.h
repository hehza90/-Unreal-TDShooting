// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CombatInteraction.h"
#include "Projectile.generated.h"

/**
 * 
 */
UCLASS()
class TDSHOOTING_API AProjectile : public ACombatInteraction
{
	GENERATED_BODY()
	
public:
	AProjectile();

	UPROPERTY(EditAnywhere)
		USphereComponent* ProjectileCollision;

	UPROPERTY(EditAnywhere)
		UStaticMeshComponent* ProjectileMesh;
	
	UPROPERTY(EditAnywhere)
		UProjectileMovementComponent* ProjectileMovement;
	
	
	UPROPERTY(EditAnywhere, Category = "Damage")
		float Damage = 50;


	UFUNCTION(BlueprintNativeEvent, Category = "Collision")
		void OnHit(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,	const FHitResult &SweepResult);
	void OnHit_Implementation(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult);



};
