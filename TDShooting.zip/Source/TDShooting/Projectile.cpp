// Fill out your copyright notice in the Description page of Project Settings.

#include "Projectile.h"
#include "Damageable.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Particles/ParticleSystemComponent.h"


AProjectile::AProjectile()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ProjectileBase"));

	}
	ProjectileCollision = CreateDefaultSubobject<USphereComponent>(TEXT("ProjectileCollision"));
	ProjectileCollision->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh"));
	ProjectileMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	ParticleSystem = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystem"));
	ParticleSystem->SetupAttachment(RootComponent);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovementComponemt"));


	ProjectileCollision->OnComponentBeginOverlap.AddDynamic(this, &AProjectile::OnHit);


}

void AProjectile::SetDamage(float _Damage)
{
	Damage = _Damage;
}

void AProjectile::Activate()
{
	IsActivate = true;
}

void AProjectile::OnHit_Implementation(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,	const FHitResult &SweepResult)
{
	if (!IsActivate)
		return;
	
	//��ƼŬ�� �����ϰ� �ı�
	ProjectileCollision->DestroyComponent();
	ProjectileMesh->DestroyComponent();
	ProjectileMovement->DestroyComponent();

	//��ƼŬ Ȱ��ȭ
	ParticleSystem->ActivateSystem();
	//Destroy();
	//�������� ���� �� �ִ� ������� Ȯ��	
	IDamageable* DamageableActor = Cast<IDamageable>(OtherActor);
	if (DamageableActor != nullptr) {
		DamageableActor->Execute_Damaged(OtherActor, Damage);		
	}	

	
}
