// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "Projectile.h"
#include "Damageable.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"



AProjectile::AProjectile()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ProjectileBase"));

	}
	ProjectileCollision = CreateDefaultSubobject<USphereComponent>(TEXT("ProjectileCollision"));
	ProjectileCollision->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh"));
	ProjectileMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovementComponemt"));


	ProjectileCollision->OnComponentBeginOverlap.AddDynamic(this, &AProjectile::OnHit);


}

void AProjectile::OnHit_Implementation(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,	const FHitResult &SweepResult)
{
	//�������� ���� �� �ִ� ������� Ȯ��	
	IDamageable* DamageableActor = Cast<IDamageable>(OtherActor);
	if (DamageableActor != nullptr) {
		DamageableActor->Execute_Damaged(OtherActor, Damage);		
	}	
	Destroy();	
}
