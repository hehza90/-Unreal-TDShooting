// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "Kismet/KismetMathLibrary.h"
#include "CombatInteraction.h"
#include "TDShootingGameModeBase.h"
#include "PlayableCharacter.h"
#include "EnemyAIController.h"
#include "EnemyCharacter.h"



AEnemyCharacter::AEnemyCharacter()
{
	
}



void AEnemyCharacter::BeginPlay()
{
	Super::BeginPlay();
	MyGameMode = (ATDShootingGameModeBase*)GetWorld()->GetAuthGameMode();
	Player = Cast<APlayableCharacter>(GetWorld()->GetFirstPlayerController()->GetPawn());
	SetEnemyStat();
	SetInitialStat();

}



void AEnemyCharacter::SetEnemyStat()
{
	MaxHealth = MaxHealth * ( FMath::Pow(1+ MyGameMode->HealthPerLevel, MyGameMode->GetCurrentLevel()));
}


void AEnemyCharacter::ToggleCanAttack()
{
	CanAttack = !CanAttack;
}


void AEnemyCharacter::Attack_Implementation()
{
	//���� ��ȯ
	FRotator DesireRotation =
		UKismetMathLibrary::FindLookAtRotation(this->GetActorLocation(), FVector(Player->GetActorLocation().X, Player->GetActorLocation().Y, this->GetActorLocation().Z));
	this->GetController()->SetControlRotation(DesireRotation);
	this->SetActorRotation(DesireRotation);

	if (CanAttack == false)
	{
		return;
	}
		
	//������Ÿ�� �߻縦 �õ�.
	if (InteractionOfEnemy)
	{
		if (AttackPoint != nullptr) 
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FVector SpawnLocation = AttackPoint->GetComponentLocation();
				FRotator SpawnRotation = AttackPoint->GetComponentRotation();
				
				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;

				// �߻�ü ����.
				ACombatInteraction* Interaction = World->SpawnActor<ACombatInteraction>(InteractionOfEnemy, SpawnLocation, SpawnRotation, SpawnParams);

				CanAttack = false;
				GetWorldTimerManager().SetTimer(CanAttackTimerHandle, this, &AEnemyCharacter::ToggleCanAttack, AttackRate, false);
			}
		}
		
	}
}


void AEnemyCharacter::Death_Implementation()
{
	Super::Death_Implementation();
	//WhenEnemyDead.Broadcast();
	
	MyGameMode->EnemyDead();

	//AI �ߴ�
	this->DetachFromControllerPendingDestroy();
	//2���� �� ���� �ı�
	FTimerHandle DestroyTimerHandle;
	GetWorldTimerManager().SetTimer(DestroyTimerHandle, this, &AEnemyCharacter::DestroyDeadbody, 2.5f, false);
}


void AEnemyCharacter::DestroyDeadbody()
{
	Destroy();
}
