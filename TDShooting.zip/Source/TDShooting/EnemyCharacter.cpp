// Fill out your copyright notice in the Description page of Project Settings.

#include "EnemyCharacter.h"
#include "TDShooting.h"
#include "Kismet/KismetMathLibrary.h"
#include "Components/ArrowComponent.h"
#include "Projectile.h"
#include "TDShootingGameModeBase.h"
#include "Components/CapsuleComponent.h"
#include "PlayableCharacter.h"
#include "EnemyAIController.h"



AEnemyCharacter::AEnemyCharacter()
{

}


void AEnemyCharacter::BeginPlay()
{
	Super::BeginPlay();
	GetWorldTimerManager().SetTimer(InvisibleTimer, this, &ABaseCharacter::DeactiveInvisible, InvisibleDeactiveTime, false);

	//���Ӹ��� �÷��̾� ����
	MyGameMode = (ATDShootingGameModeBase*)GetWorld()->GetAuthGameMode();
	Player = Cast<APlayableCharacter>(GetWorld()->GetFirstPlayerController()->GetPawn());
	
	//�ɷ�ġ ����
	SetEnemyStat();
	SetInitialStat();
}




int AEnemyCharacter::GetEnemyScore() const
{
	return ScorePoint;
}


UBehaviorTree * AEnemyCharacter::GetEnemyBehavior() const
{
	return BotBehavior;
}


void AEnemyCharacter::SetPlayerCharacter(APlayableCharacter* Target)
{
	Player = Target;
}




void AEnemyCharacter::Attack_Implementation()
{
	//���� ��ȯ
	FRotator DesireRotation =
		UKismetMathLibrary::FindLookAtRotation(this->GetActorLocation(), FVector(Player->GetActorLocation().X, Player->GetActorLocation().Y, this->GetActorLocation().Z));	
	this->SetActorRotation(DesireRotation);

	if (CanAttack == false)
	{
		return;
	}
		
	//������Ÿ�� �߻縦 �õ�.
	if (ProjectileOfEnemy)
	{
		if (AttackPoint != nullptr) 
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FVector SpawnLocation = AttackPoint->GetComponentLocation();
				FRotator SpawnRotation = AttackPoint->GetComponentRotation();
				
				FActorSpawnParameters SpawnParams;
				SpawnParams.Owner = this;
				SpawnParams.Instigator = Instigator;

				// �߻�ü ����.
				AProjectile* Projectile = World->SpawnActor<AProjectile>(ProjectileOfEnemy, SpawnLocation, SpawnRotation, SpawnParams);
				Projectile->SetDamage(EnemyDamage);
				Projectile->Activate();
				CanAttack = false;
				GetWorldTimerManager().SetTimer(CanAttackTimerHandle, this, &AEnemyCharacter::ToggleCanAttack, AttackRate, false);
			}
		}
		
	}
}


void AEnemyCharacter::Death_Implementation()
{
	Super::Death_Implementation();
	//WhenEnemyDead.Broadcast();
	
	MyGameMode->EnemyDead(this);

	//AI �ߴ�
	this->DetachFromControllerPendingDestroy();
	//2���� �� ���� �ı�
	FTimerHandle DestroyTimerHandle;
	GetWorldTimerManager().SetTimer(DestroyTimerHandle, this, &AEnemyCharacter::DestroyDeadbody, 2.5f, false);
}




void AEnemyCharacter::SetEnemyStat()
{
	MaxHealth = MaxHealth * ( FMath::Pow(1+ MyGameMode->GetHealthPerLevel(), MyGameMode->GetCurrentLevel()));
	EnemyDamage = EnemyDamage *FMath::Pow(1 + MyGameMode->GetDamagePerLevel(), MyGameMode->GetCurrentLevel());
}


void AEnemyCharacter::ToggleCanAttack()
{
	CanAttack = !CanAttack;
}


void AEnemyCharacter::DestroyDeadbody()
{
	Destroy();
}


void AEnemyCharacter::DeactiveInvisible()
{
	Super::DeactiveInvisible();
	CharacterCapsule->SetCollisionProfileName("EnemyPreset");
}
