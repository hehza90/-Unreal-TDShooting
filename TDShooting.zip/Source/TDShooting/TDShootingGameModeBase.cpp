// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShootingGameModeBase.h"
#include "CoreMinimal.h"
#include "EnemyCharacter.h"
#include "PlayableCharacter.h"
#include "TDPlayerController.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Room.h"
#include "Components/ArrowComponent.h"
#include "Blueprint/UserWidget.h"



ATDShootingGameModeBase::ATDShootingGameModeBase()
{
	CurrentState = ETDShootingGameState::GS_Idle;
}


void ATDShootingGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	//CurrentState = ETDShootingGameState::GS_Idle;

	//ù Room ����
	SpawnNextRoom(NextRoomSpawnPoint);
	PC = Cast<ATDPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	ReSpawnPlayer();


	//UI����
	UUserWidget* TempWidget;

	if (LevelInformation != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), LevelInformation);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	}

	if (PlayerInfoWidget != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), PlayerInfoWidget);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	} 

}



uint8 ATDShootingGameModeBase::GetCurrentLevel() const
{
	return CurrentLevel;
}

float ATDShootingGameModeBase::GetHealthPerLevel() const
{
	return HealthPerLevel;
}

float ATDShootingGameModeBase::GetDamagePerLevel() const
{
	return DamagePerLevel;
}



void ATDShootingGameModeBase::StartLevel_Implementation()
{	
	CurrentLevel++;	
	PreviousRoom = CurrentRoom;
	//NextRoom�� ���� CurrentRoom��
	CurrentRoom = NextRoom;
	
	
	//���� ����
	ETDShootingGameState::GS_Spawning;
	RemainNumber = NumberToSpawn;

	GetWorldTimerManager().SetTimer(EnemySpawnTimerHandle, this, &ATDShootingGameModeBase::SpawnEnemy, SpawnDelay, true);    

	//���� �� ����
	if(PreviousRoom)
	{
		PreviousRoom->Destroy();
	}	

}

void ATDShootingGameModeBase::EndLevel_Implementation()
{			
	CurrentState = ETDShootingGameState::GS_Idle;
	//SpawnedNumber �� �ʱ�ȭ
	SpawnedNumber = 0;
	//GetAttachPoint ���� �� ������ġ�� ����
	NextRoomSpawnPoint = CurrentRoom->GetAttachPoint();
	//���� �� ����
	SpawnNextRoom(NextRoomSpawnPoint);
	//�볢�� ����
	CurrentRoom->OpenToNextRoom();
	NextRoom->OpenToPreviousRoom();	
}

void ATDShootingGameModeBase::GameOver_Implementation()
{
	IsGameOver =true;
		
	//���ӿ��� UI
	if (GameOverWidget != nullptr)
	{
		UUserWidget* TempWidget;
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), GameOverWidget);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	}
}




void ATDShootingGameModeBase::SpawnEnemy_Implementation()
{		
	//������ �� �Ǿ��ٸ�
	if(SpawnedNumber>= NumberToSpawn)
	{
		GetWorldTimerManager().ClearTimer(EnemySpawnTimerHandle);
		CurrentState = ETDShootingGameState::GS_Playing;
		return;
	}
	
	//�� ����߿� �ϳ��� ������
	uint32 EnemyIndex = FMath::RandRange(0, EnemyList.Num() - 1);

	if (EnemyList[EnemyIndex])
	{
		FVector SpawnLocation;
		FRotator SpawnRotation;

		SpawnLocation = FVector(0, 0, 0);
		SpawnRotation = FRotator(0, 0, 0);

		//��ġ ����
		if (CurrentRoom)
		{
			UArrowComponent* SpawnPoint = CurrentRoom->GetSpawnPoint();
			if (SpawnPoint)
			{
				SpawnLocation = SpawnPoint->GetComponentLocation();
				SpawnRotation = SpawnPoint->GetComponentRotation();
			}
		}

		//������ 
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			AEnemyCharacter* NewEnemy = World->SpawnActor<AEnemyCharacter>(EnemyList[EnemyIndex], SpawnLocation, SpawnRotation, SpawnParams);
			
				
			SpawnedNumber++;
		}
	}
		
}

void ATDShootingGameModeBase::EnemyDead_Implementation(AEnemyCharacter* DeadEnemy)
{
	//���ھ� �߰� ������ ����
	PC->AddScore(DeadEnemy->GetEnemyScore());
	ReduceRemainNumber();
}



void ATDShootingGameModeBase::SpawnNextRoom(UArrowComponent* SpawnPoint)
{
	//�������� ����
	uint8 RoomIndex = FMath::RandRange(0, RoomList.Num()-1);
	
	if (RoomList[RoomIndex])
	{
		FVector SpawnLocation; 
		FRotator SpawnRotation;
		
		//��ġ ����
		if (SpawnPoint)
		{
			SpawnLocation = SpawnPoint->GetComponentLocation();
			SpawnRotation = SpawnPoint->GetComponentRotation();
		}
		//���ٸ� 0
		else
		{
			SpawnLocation = FVector(0, 0, 0);
			SpawnRotation = FRotator(0, 0, 0);
		}
		//���� Room������ NextRoom����
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			
			//�� ����
			ARoom* NewRoom = World->SpawnActor<ARoom>(RoomList[RoomIndex], SpawnLocation, SpawnRotation, SpawnParams);
						
			//NextRoom �� �Ҵ�
			NextRoom = NewRoom;
			
		}	
		
	}
	
}



void ATDShootingGameModeBase::WhenPlayerDead()
{
	//������ Ÿ�̸�
	GetWorldTimerManager().SetTimer(ReSpawnTimerHandle, this, &ATDShootingGameModeBase::ReSpawnPlayer, ReSpawnDelay, false);	
}

void ATDShootingGameModeBase::WhenPlayerSpawn_Implementation()
{
	PC->RedusePlayerLife();//������ ����
}



void ATDShootingGameModeBase::ReduceRemainNumber()
{
	RemainNumber--;

	if (CurrentState == ETDShootingGameState::GS_Playing && RemainNumber <= 0)
	{
		EndLevel();
	}
}

void ATDShootingGameModeBase::ReSpawnPlayer()
{
	
	if (IsGameOver == true)
	{
		return;
	}

	if (Life <= 0)
	{
		GameOver();
		return;
	}

	Life--;
	
	APlayerController* MyController = GetWorld()->GetFirstPlayerController();

	
	APlayableCharacter* Player = Cast<APlayableCharacter>(UGameplayStatics::GetPlayerPawn(GetWorld(), 0));

	FVector SpawnLocation = FVector(0, 0, 100);
	FRotator SpawnRotation = FRotator(0, 0, 0);

	//�÷��̾ �ִٸ� ����
	if (Player)
	{
		SpawnLocation = Player->GetActorLocation();
		SpawnRotation = Player->GetActorRotation();
		UGameplayStatics::GetPlayerController(GetWorld(), 0)->UnPossess();
		//������ �÷��̾� ����				
		Player->Destroy();
	}
	else
	{
		return;
	}
		

	//�÷��̾� ������ Possess
	//������ 
	UWorld* const World = GetWorld();
	if (World)
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.Owner = this;
		SpawnParams.Instigator = Instigator;
		if (PlayerBlueprint)
		{		
			APlayableCharacter* ReSpawnedPlayer = World->SpawnActor<APlayableCharacter>(PlayerBlueprint, SpawnLocation, SpawnRotation, SpawnParams);
			if (ReSpawnedPlayer)
			{
				UGameplayStatics::GetPlayerController(GetWorld(), 0)->Possess(ReSpawnedPlayer);				
				
			}
		}
	}


	WhenPlayerSpawn();

}

