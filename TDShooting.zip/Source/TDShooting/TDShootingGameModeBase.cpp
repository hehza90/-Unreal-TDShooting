// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "EnemyCharacter.h"
#include "Room.h"
#include "TDShootingGameModeBase.h"
#include "Blueprint/UserWidget.h"



ATDShootingGameModeBase::ATDShootingGameModeBase()
{
	CurrentState = ETDShootingGameState::GS_Idle;
}


void ATDShootingGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	//CurrentState = ETDShootingGameState::GS_Idle;

	//ù Room ����
	SpawnNextRoom(NextRoomSpawnPoint);

	UUserWidget* TempWidget;

	if (HPWidget != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), LevelInformation);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	}

	if (HPWidget != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), HPWidget);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	} 

	if (AmmoWidget != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), AmmoWidget);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	}
	if (ReloadWidget != nullptr)
	{
		TempWidget = CreateWidget<UUserWidget>(GetWorld(), ReloadWidget);
		if (TempWidget != nullptr)
		{
			TempWidget->AddToViewport();
		}
	}
	
}


uint8 ATDShootingGameModeBase::GetCurrentLevel()
{
	return CurrentLevel;
}


void ATDShootingGameModeBase::StartLevel_Implementation()
{	
	CurrentLevel++;	
	PreviousRoom = CurrentRoom;
	//NextRoom�� ���� CurrentRoom��
	CurrentRoom = NextRoom;
	
	
	//���� ����
	ETDShootingGameState::GS_Spawning;
	GetWorldTimerManager().SetTimer(EnemySpawnTimerHandle, this, &ATDShootingGameModeBase::SpawnEnemy, SpawnDelay, true);    

	//���� �� ����
	if(PreviousRoom)
	{
		PreviousRoom->Destroy();
	}	

}


void ATDShootingGameModeBase::EndLevel_Implementation()
{			
	CurrentState = ETDShootingGameState::GS_Idle;
	//SpawnedNumber �� �ʱ�ȭ
	SpawnedNumber = 0;
	//GetAttachPoint ���� �� ������ġ�� ����
	NextRoomSpawnPoint = CurrentRoom->GetAttachPoint();
	//���� �� ����
	SpawnNextRoom(NextRoomSpawnPoint);
	//�볢�� ����
	CurrentRoom->OpenToNextRoom();
	NextRoom->OpenToPreviousRoom();

}


void ATDShootingGameModeBase::ReduceRemainNumber()
{	
	RemainNumber--;

	if(CurrentState == ETDShootingGameState::GS_Playing && RemainNumber<=0)
	{
		EndLevel();
	}
}


void ATDShootingGameModeBase::SpawnEnemy_Implementation()
{		
	if(SpawnedNumber>= NumberToSpawn)
	{
		GetWorldTimerManager().ClearTimer(EnemySpawnTimerHandle);
		CurrentState = ETDShootingGameState::GS_Playing;
		return;
	}
	

	uint32 EnemyIndex = FMath::RandRange(0, EnemyList.Num() - 1);

	if (EnemyList[EnemyIndex])
	{
		FVector SpawnLocation;
		FRotator SpawnRotation;

		SpawnLocation = FVector(0, 0, 0);
		SpawnRotation = FRotator(0, 0, 0);

			//��ġ ����
		if (CurrentRoom)
		{
			UArrowComponent* SpawnPoint = CurrentRoom->GetSpawnPoint();
			if (SpawnPoint)
			{
				SpawnLocation = SpawnPoint->GetComponentLocation();
				SpawnRotation = SpawnPoint->GetComponentRotation();
			}
		}

		//������ 
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			AEnemyCharacter* NewEnemy = World->SpawnActor<AEnemyCharacter>(EnemyList[EnemyIndex], SpawnLocation, SpawnRotation, SpawnParams);
			
		
			RemainNumber++;
			SpawnedNumber++;
		}
	}
		
}


void ATDShootingGameModeBase::EnemyDead_Implementation()
{
	ReduceRemainNumber();
}


void ATDShootingGameModeBase::SpawnNextRoom(UArrowComponent* SpawnPoint)
{
	//�������� ����
	uint8 RoomIndex = FMath::RandRange(0, RoomList.Num()-1);
	
	if (RoomList[RoomIndex])
	{
		FVector SpawnLocation; 
		FRotator SpawnRotation;
		
		//��ġ ����
		if (SpawnPoint)
		{
			SpawnLocation = SpawnPoint->GetComponentLocation();
			SpawnRotation = SpawnPoint->GetComponentRotation();
		}
		//���ٸ� 0
		else
		{
			SpawnLocation = FVector(0, 0, 0);
			SpawnRotation = FRotator(0, 0, 0);
		}
		//���� Room������ NextRoom����
		UWorld* const World = GetWorld();
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.Instigator = Instigator;
			
			//�� ����
			ARoom* NewRoom = World->SpawnActor<ARoom>(RoomList[RoomIndex], SpawnLocation, SpawnRotation, SpawnParams);
						
			//NextRoom �� �Ҵ�
			NextRoom = NewRoom;
			
		}	
		
	}

}





