// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "CombatInteraction.h"


// Sets default values
ACombatInteraction::ACombatInteraction()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ACombatInteraction::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ACombatInteraction::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

