// Fill out your copyright notice in the Description page of Project Settings.

#include "Obstacle.h"
#include "Runtime/Engine/Classes/Components/BoxComponent.h"
#include "TDShooting.h"



// Sets default values
AObstacle::AObstacle()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	if (!RootComponent)
	{
		RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootBase"));
	}

	Collision = CreateDefaultSubobject<UBoxComponent>(TEXT("Collision"));
	Collision->SetupAttachment(RootComponent);

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(Collision);
}

// Called when the game starts or when spawned
void AObstacle::BeginPlay()
{
	Super::BeginPlay();
	CurrentDurability = MaxDurability;	
}

// Called every frame
void AObstacle::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AObstacle::Damaged_Implementation(float Amount)
{
	CalculateDurability();
}


void AObstacle::CalculateDurability_Implementation()
{
	CurrentDurability-= DamagePerHit;
	CalculateBreak();
}


void AObstacle::Break_Implementation()
{
	Destroy(this);
}


void AObstacle::CalculateBreak()
{
	if(CurrentDurability<=0)
	{
		Break();
	}
}

