// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "BaseCharacter.h"


// Sets default values
ABaseCharacter::ABaseCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	AttackPoint = CreateDefaultSubobject<UArrowComponent>(TEXT("AttackPoint"));
	AttackPoint->SetupAttachment(RootComponent);

	//ĳ�� �� �ٽ� ������Ʈ ����
	CharacterDirection = this->FindComponentByClass<UArrowComponent>();
	CharacterCapsule = this->FindComponentByClass<UCapsuleComponent>();
	CharacterMesh = this->FindComponentByClass<UMeshComponent>();	
	
}

// Called when the game starts or when spawned
void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();		
}

// Called every frame
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void ABaseCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}


void ABaseCharacter::SetInitialStat()
{
	CurrentHealth = MaxHealth;
}


void ABaseCharacter::CalculateHealth_Implementation(float Amount)
{		
	CurrentHealth += Amount;
	CalculateDead();
}




void ABaseCharacter::CalculateDead()
{
	if (CurrentHealth <= 0)
	{		
		Death();
	}
}


void ABaseCharacter::Attack_Implementation()
{	
}


void ABaseCharacter::Damaged_Implementation(float Amount)
{	
	CalculateHealth(-Amount);		
}


void ABaseCharacter::Death_Implementation()
{
	IsDead = true;
	//��ü�� ���� ���࿡ ���ذ� ���� �ʵ��� �ݸ��� ä���� ����
	CharacterCapsule->SetCollisionProfileName("DeadPreset");
}