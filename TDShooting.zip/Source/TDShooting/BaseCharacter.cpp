// Fill out your copyright notice in the Description page of Project Settings.

#include "BaseCharacter.h"
#include "Components/ArrowComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/MeshComponent.h"
#include "Particles/ParticleSystemComponent.h"

// Sets default values
ABaseCharacter::ABaseCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	
	//ĳ�� �� �ٽ� ������Ʈ ����
	AttackPoint = CreateDefaultSubobject<UArrowComponent>(TEXT("AttackPoint"));
	AttackPoint->SetupAttachment(RootComponent);

	InvisibleParticle = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("InvisibleParticle"));
	InvisibleParticle->SetupAttachment(RootComponent);

	
	CharacterDirection = this->FindComponentByClass<UArrowComponent>();
	CharacterCapsule = this->FindComponentByClass<UCapsuleComponent>();
	CharacterMesh = this->FindComponentByClass<UMeshComponent>();	

	
}

// Called when the game starts or when spawned
void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();		
}

// Called every frame
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void ABaseCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}


void ABaseCharacter::SetInitialStat()
{
	CurrentHealth = MaxHealth;
}


void ABaseCharacter::CalculateHealth_Implementation(float Amount)
{		
	CurrentHealth += Amount;
	CalculateDead();
}


void ABaseCharacter::CalculateDead()
{
	if (CurrentHealth <= 0)
	{		
		Death();
	}
}


void ABaseCharacter::Attack_Implementation()
{	
}


void ABaseCharacter::Damaged_Implementation(float Amount)
{	
	CalculateHealth(-Amount);		
}


void ABaseCharacter::Death_Implementation()
{
	IsDead = true;
	//��ü�� ���� ���࿡ ���ذ� ���� �ʵ��� �ݸ��� ä���� ����
	CharacterCapsule->SetCollisionProfileName("DeadPreset");
}


void ABaseCharacter::DeactiveInvisible()
{	
	InvisibleParticle->DeactivateSystem();
}

