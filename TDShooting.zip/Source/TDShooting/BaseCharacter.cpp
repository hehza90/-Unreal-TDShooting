// Fill out your copyright notice in the Description page of Project Settings.

#include "TDShooting.h"
#include "BaseCharacter.h"


// Sets default values
ABaseCharacter::ABaseCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	//ĳ�� �� �ٽ� ������Ʈ ����
	CharacterDirection = this->FindComponentByClass<UArrowComponent>();
	CharacterCapsule = this->FindComponentByClass<UCapsuleComponent>();
	CharacterMesh = this->FindComponentByClass<UMeshComponent>();
	CurrentHealth = MaxHealth;
}

// Called when the game starts or when spawned
void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void ABaseCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}


void ABaseCharacter::CalculateHealth(float Delta)
{
	CurrentHealth = CurrentHealth + Delta;
	CalculateDead();
}


float ABaseCharacter::GetMaxHealth() const
{
	return MaxHealth;
}

float ABaseCharacter::GetCurrentHealth() const
{
	return CurrentHealth;
}

void ABaseCharacter::CalculateDead()
{
	if (CurrentHealth <= 0)
	{		
		Death();
	}
}


void ABaseCharacter::Attack_Implementation()
{
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT("Base CharacterAttack")));
}

float ABaseCharacter::Damaged_Implementation(float Amount)
{
	CalculateHealth(-Amount);	
	return 0.0f;
}

void ABaseCharacter::Death_Implementation()
{
	IsDead = true;
	CharacterCapsule->SetCollisionProfileName("DeadPreset");
}